-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: elms_bts
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_audit`
--

DROP TABLE IF EXISTS `access_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access_audit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `role` enum('admin','trainer','trainee','guest') NOT NULL,
  `course_code` varchar(50) NOT NULL,
  `batch_name` varchar(100) NOT NULL,
  `action` varchar(64) NOT NULL,
  `resource_type` varchar(32) DEFAULT NULL,
  `resource_id` int(11) DEFAULT NULL,
  `interface` varchar(16) NOT NULL DEFAULT 'web',
  `endpoint` varchar(255) DEFAULT NULL,
  `ip_address` varchar(64) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_access_audit_user` (`user_id`,`role`),
  KEY `idx_access_audit_course_batch` (`course_code`,`batch_name`),
  KEY `idx_access_audit_action` (`action`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_audit`
--

LOCK TABLES `access_audit` WRITE;
/*!40000 ALTER TABLE `access_audit` DISABLE KEYS */;
INSERT INTO `access_audit` VALUES (1,'21107477','trainer','ASNCI','ASNCI Batch 2','VIEW_COURSE_DETAILS',NULL,NULL,'web','/bts/php/get_course_details_trainer.php?course_code=ASNCI&batch_name=ASNCI%20Batch%202','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-02 15:29:27'),(2,'21107477','trainer','ASNCI','ASNCI Batch 2','VIEW_COURSE_DETAILS',NULL,NULL,'web','/bts/php/get_course_details_trainer.php?course_code=ASNCI&batch_name=ASNCI%20Batch%202','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-02 15:29:39'),(3,'21107477','trainer','ASNCI','ASNCI Batch 2','VIEW_COURSE_DETAILS',NULL,NULL,'web','/bts/php/get_course_details_trainer.php?course_code=ASNCI&batch_name=ASNCI%20Batch%202','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-02 15:31:28'),(4,'21107477','trainer','ASNCI','ASNCI Batch 2','VIEW_COURSE_DETAILS',NULL,NULL,'web','/bts/php/get_course_details_trainer.php?course_code=ASNCI&batch_name=ASNCI%20Batch%202','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-02 15:31:51'),(5,'21107477','trainer','ASNCI','ASNCI Batch 2','VIEW_COURSE_DETAILS',NULL,NULL,'web','/bts/php/get_course_details_trainer.php?course_code=ASNCI&batch_name=ASNCI%20Batch%202','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-02 15:33:56'),(6,'21107477','trainer','ASNCI','ASNCI Batch 2','VIEW_COURSE_DETAILS',NULL,NULL,'web','/bts/php/get_course_details_trainer.php?course_code=ASNCI&batch_name=ASNCI%20Batch%202','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-02 15:34:09'),(7,'21107477','trainer','ASNCI','ASNCI Batch 2','VIEW_COURSE_DETAILS',NULL,NULL,'web','/bts/php/get_course_details_trainer.php?course_code=ASNCI&batch_name=ASNCI%20Batch%202','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-02 15:35:19'),(8,'21107477','trainer','ASNCI','ASNCI Batch 2','VIEW_COURSE_DETAILS',NULL,NULL,'web','/bts/php/get_course_details_trainer.php?course_code=ASNCI&batch_name=ASNCI%20Batch%202','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-02 15:35:21'),(9,'21107477','trainer','ASNCI','ASNCI Batch 2','VIEW_COURSE_DETAILS',NULL,NULL,'web','/bts/php/get_course_details_trainer.php?course_code=ASNCI&batch_name=ASNCI%20Batch%202','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-02 16:25:27'),(10,'21107477','trainer','ASNCI','ASNCI Batch 2','VIEW_COURSE_DETAILS',NULL,NULL,'web','/bts/php/get_course_details_trainer.php?course_code=ASNCI&batch_name=ASNCI%20Batch%202','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-02 16:25:32'),(11,'21107477','trainer','ASNCI','ASNCI Batch 2','VIEW_COURSE_DETAILS',NULL,NULL,'web','/bts/php/get_course_details_trainer.php?course_code=ASNCI&batch_name=ASNCI%20Batch%202','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-02 16:25:33'),(12,'21107477','trainer','ASNCI','ASB1','VIEW_COURSE_DETAILS',NULL,NULL,'web','/bts/php/get_course_details_trainer.php?course_code=ASNCI&batch_name=ASB1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-02 16:26:11'),(13,'21107477','trainer','ASNCI','ASB1','VIEW_COURSE_DETAILS',NULL,NULL,'web','/bts/php/get_course_details_trainer.php?course_code=ASNCI&batch_name=ASB1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-02 16:26:52');
/*!40000 ALTER TABLE `access_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trainer_id` varchar(20) NOT NULL,
  `action` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`trainer_id`),
  CONSTRAINT `activities_ibfk_1` FOREIGN KEY (`trainer_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activity_submissions`
--

DROP TABLE IF EXISTS `activity_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_submissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activity_id` int(11) DEFAULT NULL,
  `guest_id` varchar(50) DEFAULT NULL,
  `submission_text` text DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `score` decimal(5,2) DEFAULT NULL,
  `graded_by` varchar(50) DEFAULT NULL,
  `graded_at` timestamp NULL DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_id` (`activity_id`),
  KEY `trainee_id` (`guest_id`),
  CONSTRAINT `activity_submissions_ibfk_1` FOREIGN KEY (`activity_id`) REFERENCES `topic_activities` (`id`),
  CONSTRAINT `activity_submissions_ibfk_2` FOREIGN KEY (`guest_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_submissions`
--

LOCK TABLES `activity_submissions` WRITE;
/*!40000 ALTER TABLE `activity_submissions` DISABLE KEYS */;
INSERT INTO `activity_submissions` VALUES (1,2,'31123082','','sub_2_31123082_1764523698.txt','2025-11-30 17:28:18',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `activity_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `posted_by` varchar(20) DEFAULT NULL,
  `date_posted` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `posted_by` (`posted_by`),
  CONSTRAINT `announcements_ibfk_1` FOREIGN KEY (`posted_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
INSERT INTO `announcements` VALUES (1,'Ann','Ann','1000000001','2025-11-19 15:56:19'),(2,'New Announcement','Announcement Name','1000000001','2025-11-23 03:50:44');
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_assignment_status`
--

DROP TABLE IF EXISTS `batch_assignment_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_assignment_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_code` varchar(50) NOT NULL,
  `batch_name` varchar(100) NOT NULL,
  `trainer_id` varchar(50) DEFAULT NULL,
  `trainee_id` varchar(50) DEFAULT NULL,
  `status` enum('active','archived') NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `assigned_at` timestamp NULL DEFAULT NULL,
  `archived_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_trainer` (`trainer_id`),
  KEY `idx_trainee` (`trainee_id`),
  KEY `idx_course_batch` (`course_code`,`batch_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_assignment_status`
--

LOCK TABLES `batch_assignment_status` WRITE;
/*!40000 ALTER TABLE `batch_assignment_status` DISABLE KEYS */;
INSERT INTO `batch_assignment_status` VALUES (1,'TC1','Test Batch 1',NULL,NULL,'active','2025-12-26','2026-05-06','2025-11-28 15:01:16',NULL),(2,'TC1','Test Batch 2',NULL,NULL,'active','2026-05-26','2026-10-04','2025-11-28 15:02:01',NULL),(3,'ASNCI','ASB1',NULL,NULL,'active','2026-01-05','2026-05-30','2025-12-01 14:49:09',NULL),(4,'ASNCI','ASNCI Batch 2',NULL,NULL,'active','2025-06-09','2025-11-01','2025-12-01 14:50:12',NULL);
/*!40000 ALTER TABLE `batch_assignment_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_assignments`
--

DROP TABLE IF EXISTS `batch_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trainee_id` varchar(20) NOT NULL,
  `trainer_id` varchar(50) NOT NULL,
  `course_code` varchar(50) NOT NULL,
  `batch_name` text NOT NULL,
  `date_assigned` datetime DEFAULT current_timestamp(),
  `assigned_by` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `trainee_id` (`trainee_id`),
  KEY `course_code` (`course_code`),
  KEY `assigned_by` (`assigned_by`),
  KEY `batch_id` (`batch_name`(768)),
  KEY `trainer_id` (`trainer_id`),
  CONSTRAINT `batch_assignments_ibfk_1` FOREIGN KEY (`trainee_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `batch_assignments_ibfk_2` FOREIGN KEY (`course_code`) REFERENCES `courses` (`course_code`),
  CONSTRAINT `batch_assignments_ibfk_3` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `batch_assignments_ibfk_5` FOREIGN KEY (`trainer_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_assignments`
--

LOCK TABLES `batch_assignments` WRITE;
/*!40000 ALTER TABLE `batch_assignments` DISABLE KEYS */;
INSERT INTO `batch_assignments` VALUES (9,'31123082','21107477','ASNCI','ASB1','2025-12-02 07:25:22','1000000001'),(10,'31107421','21107477','ASNCI','ASNCI Batch 2','2025-12-02 07:25:33','1000000001'),(11,'411071438','21107477','ASNCI','ASB1','2025-12-02 16:05:01','1000000001');
/*!40000 ALTER TABLE `batch_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_resources`
--

DROP TABLE IF EXISTS `batch_resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_resources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_code` varchar(50) NOT NULL,
  `batch_name` varchar(100) NOT NULL,
  `resource_type` enum('material','activity') NOT NULL,
  `resource_id` int(11) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_batch_resource` (`resource_type`,`resource_id`,`course_code`,`batch_name`),
  KEY `idx_batch_resources_course_batch` (`course_code`,`batch_name`),
  CONSTRAINT `fk_batch_resources_course_batch` FOREIGN KEY (`course_code`, `batch_name`) REFERENCES `course_batches` (`course_code`, `batch_name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_resources`
--

LOCK TABLES `batch_resources` WRITE;
/*!40000 ALTER TABLE `batch_resources` DISABLE KEYS */;
/*!40000 ALTER TABLE `batch_resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_name` varchar(255) NOT NULL,
  `branch_code` varchar(50) NOT NULL,
  `address` text DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `branch_code` (`branch_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches`
--

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `certificates`
--

DROP TABLE IF EXISTS `certificates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `certificates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trainee_id` varchar(50) NOT NULL,
  `course_code` varchar(50) NOT NULL,
  `certificate_number` varchar(100) NOT NULL,
  `issue_date` date NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `final_grade` decimal(5,2) DEFAULT NULL,
  `certificate_path` varchar(500) DEFAULT NULL,
  `status` enum('active','expired','revoked') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `certificate_number` (`certificate_number`),
  KEY `trainee_id` (`trainee_id`),
  KEY `course_code` (`course_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificates`
--

LOCK TABLES `certificates` WRITE;
/*!40000 ALTER TABLE `certificates` DISABLE KEYS */;
/*!40000 ALTER TABLE `certificates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `competencies`
--

DROP TABLE IF EXISTS `competencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `competencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `competency_code` varchar(50) NOT NULL,
  `unit_order` int(10) unsigned DEFAULT NULL,
  `competency_name` varchar(255) NOT NULL,
  `module_title` varchar(255) DEFAULT NULL,
  `competency_type` enum('basic','common','core') NOT NULL,
  `nominal_hours` int(10) unsigned DEFAULT NULL,
  `description` text DEFAULT NULL,
  `learning_outcomes` mediumtext DEFAULT NULL,
  `hours_per_session` int(11) NOT NULL,
  `status` enum('active','archived') DEFAULT 'active',
  `date_created` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `competency_code` (`competency_code`),
  KEY `idx_comp_course_type_order` (`course_id`,`competency_type`,`unit_order`),
  CONSTRAINT `competencies_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `competencies`
--

LOCK TABLES `competencies` WRITE;
/*!40000 ALTER TABLE `competencies` DISABLE KEYS */;
INSERT INTO `competencies` VALUES (1,2,'CC-B-Comp1',NULL,'Basic Competency 1','Basic Competency 1','basic',0,'Work with others','',0,'active','2025-11-28 14:37:48'),(2,3,'TC1-Basic-1',NULL,'Test Basic 1','Test Basic 1','basic',0,'Test','',0,'active','2025-11-28 15:00:15'),(3,3,'TC1-Basic-2',NULL,'Test Basic 2','Test Basic 2','basic',0,'Test basic 2','',0,'active','2025-11-28 15:00:15'),(4,3,'TC1-Common-1',NULL,'Test Common 1','Test Common 1','common',0,'Test common 1','',0,'active','2025-11-28 15:00:15'),(5,3,'TC1-Common-2',NULL,'Test Common 2','Test Common 2','common',0,'Test common 2','',0,'active','2025-11-28 15:00:15'),(6,3,'TC1-Core-1',NULL,'Test Core 1','Test Core 1','core',0,'Test core 1','',0,'active','2025-11-28 15:00:15'),(7,5,'UNIT-692d9dcc4a714-Basic-1',1,'Receive and respond','Receiving and responding','basic',8,'Desc','<p>Follow routine spoken messages</p>',0,'active','2025-12-01 13:53:16'),(8,6,'ASNCI-Basic-1',1,'Receive and respond to workplace communication','Receiving and responding to workplace communication','basic',8,'','Follow routine spoken messages\r\nPerform workplace duties following written notices',0,'active','2025-12-01 14:25:33'),(9,6,'ASNCI-Basic-2',2,'Work with others','Working with others','basic',3,'','Develop effective workplace relationship.\r\nContribute to work group activities\r\n',0,'active','2025-12-01 14:25:33'),(10,6,'ASNCI-Basic-3',3,'Solve/address routine problems','Solving/ addressing routine problems','basic',4,'','Identify the problem \r\nAssess fundamental causes of the problem\r\nDetermine corrective action\r\nCommunicate action plans & recommendations to routine problems\r\n',0,'active','2025-12-01 14:25:33'),(11,6,'ASNCI-Common-1',1,'Validate vehicle specification','Validating vehicle specification','common',17,'','Check body type of the vehicle\r\nCheck vehicle engine type\r\nCheck vehicle specifications\r\nComplete validation of vehicle specification\r\n',0,'active','2025-12-01 14:25:33'),(12,6,'ASNCI-Common-2',2,'Move and Position Vehicle','Moving and Positioning Vehicle','common',40,'','Prepare vehicle for operation\r\nPosition vehicle\r\nPark and stop the vehicle\r\n',0,'active','2025-12-01 14:25:33'),(13,6,'ASNCI-Core-1',1,'Perform pre-delivery inspection','Performing pre-delivery inspection','core',33,'','Prepare for pre-deliver inspection\r\nPerform physical and functional inspection\r\nComplete work processes\r\n',0,'active','2025-12-01 14:25:33'),(14,6,'ASNCI-Core-2',2,'Perform periodic maintenance of automotive engine','Performing periodic maintenance of automotive engine','core',136,'','Prepare for inspection and service engine\r\nInspect engine\r\nService engine\r\nComplete work processes\r\n',0,'active','2025-12-01 14:25:33');
/*!40000 ALTER TABLE `competencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_assignments`
--

DROP TABLE IF EXISTS `course_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trainer_id` varchar(20) NOT NULL,
  `course_code` varchar(50) NOT NULL,
  `date_assigned` datetime DEFAULT current_timestamp(),
  `assigned_by` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_assignment` (`trainer_id`,`course_code`),
  KEY `course_code` (`course_code`),
  KEY `assigned_by` (`assigned_by`),
  CONSTRAINT `course_assignments_ibfk_1` FOREIGN KEY (`trainer_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `course_assignments_ibfk_2` FOREIGN KEY (`course_code`) REFERENCES `courses` (`course_code`),
  CONSTRAINT `course_assignments_ibfk_3` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_assignments`
--

LOCK TABLES `course_assignments` WRITE;
/*!40000 ALTER TABLE `course_assignments` DISABLE KEYS */;
INSERT INTO `course_assignments` VALUES (20,'21107477','ASNCI','2025-12-02 16:25:54','1000000001');
/*!40000 ALTER TABLE `course_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_batches`
--

DROP TABLE IF EXISTS `course_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_batches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_code` varchar(50) NOT NULL,
  `batch_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_by` varchar(20) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `trainer_id` varchar(50) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_batch` (`course_code`,`batch_name`),
  UNIQUE KEY `uniq_course_batch` (`course_code`,`batch_name`),
  UNIQUE KEY `uniq_course_batch_trainer` (`course_code`,`batch_name`,`trainer_id`),
  KEY `created_by` (`created_by`),
  KEY `trainer_id` (`trainer_id`),
  KEY `idx_course_batch_trainer` (`course_code`,`batch_name`,`trainer_id`),
  CONSTRAINT `course_batches_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `courses` (`course_code`),
  CONSTRAINT `course_batches_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `course_batches_ibfk_3` FOREIGN KEY (`trainer_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_batches`
--

LOCK TABLES `course_batches` WRITE;
/*!40000 ALTER TABLE `course_batches` DISABLE KEYS */;
INSERT INTO `course_batches` VALUES (1,'NC2','Batch 1','First Batch for this course','1000000001','2025-11-19 20:57:00',NULL,NULL,NULL),(2,'NC2','Batch 2','2nd batch for this course','1000000001','2025-11-19 21:02:50',NULL,NULL,NULL),(5,'CC1','B1','Batch 1','1000000001','2025-11-25 16:37:35',NULL,'2025-11-30','2026-05-22'),(6,'TC1','Test Batch 1','Test batch 1','1000000001','2025-11-28 15:01:16',NULL,'2025-12-26','2026-05-06'),(7,'TC1','Test Batch 2','Test batch 2','1000000001','2025-11-28 15:02:01',NULL,'2026-05-26','2026-10-04'),(8,'ASNCI','ASB1','Automotive Servicing Batch 1','1000000001','2025-12-01 14:49:09','21107477','2026-01-05','2026-05-30'),(9,'ASNCI','ASNCI Batch 2','Automotive Servicing NC 1 Batch 2','1000000001','2025-12-01 14:50:12',NULL,'2025-06-09','2025-11-01');
/*!40000 ALTER TABLE `course_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_materials`
--

DROP TABLE IF EXISTS `course_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_code` varchar(50) NOT NULL,
  `competency_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content_type` enum('pdf','video','text','quiz','assignment','assessment') NOT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `competency_type` enum('basic','common','core') NOT NULL,
  `activity_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`activity_data`)),
  `is_locked` tinyint(1) DEFAULT 0,
  `access_code` varchar(100) DEFAULT NULL,
  `randomize_questions` tinyint(1) DEFAULT 0,
  `prevent_sharing` tinyint(1) DEFAULT 0,
  `date_created` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `course_code` (`course_code`),
  KEY `competency_id` (`competency_id`),
  CONSTRAINT `course_materials_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `courses` (`course_code`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `course_materials_ibfk_2` FOREIGN KEY (`competency_id`) REFERENCES `competencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_materials`
--

LOCK TABLES `course_materials` WRITE;
/*!40000 ALTER TABLE `course_materials` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_topics`
--

DROP TABLE IF EXISTS `course_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_code` varchar(50) NOT NULL,
  `competency_id` varchar(255) NOT NULL,
  `topic_name` varchar(255) NOT NULL,
  `topic_description` text DEFAULT NULL,
  `learning_objectives` text DEFAULT NULL,
  `added_by` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `course_code` (`course_code`),
  KEY `added_by` (`added_by`),
  CONSTRAINT `course_topics_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `courses` (`course_code`),
  CONSTRAINT `course_topics_ibfk_2` FOREIGN KEY (`added_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_topics`
--

LOCK TABLES `course_topics` WRITE;
/*!40000 ALTER TABLE `course_topics` DISABLE KEYS */;
INSERT INTO `course_topics` VALUES (1,'NC2','Baic One','Topic','topiko','objectib','21107477','2025-11-07 16:15:51'),(2,'TC1','TC1-Basic-1','Basic Competency 1','ADadfasdfasdf','AFDSfasf','21107477','2025-11-30 16:26:58'),(3,'ASNCI','8','ajhsfbklajhsdbf','sldjfhgldsbfglkjbs','hdfghdfghrdthdfg','21107477','2025-12-02 16:26:47');
/*!40000 ALTER TABLE `course_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(255) NOT NULL,
  `competency_name` varchar(255) NOT NULL,
  `module_title` varchar(100) NOT NULL,
  `course_code` varchar(50) NOT NULL,
  `hours` int(11) NOT NULL,
  `nominal_hours` int(10) unsigned NOT NULL,
  `description` text DEFAULT NULL,
  `learning_outcomes` mediumtext NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('active','archived') DEFAULT 'active',
  `course_status` enum('draft','published','archived') DEFAULT 'draft',
  `allow_preview` tinyint(1) DEFAULT 0,
  `preview_content` text DEFAULT NULL,
  `require_verification` tinyint(1) DEFAULT 0,
  `verification_type` enum('email','student_id','phone') DEFAULT 'email',
  `date_created` datetime DEFAULT current_timestamp(),
  `branch_id` int(11) DEFAULT NULL,
  `schedule_days_per_week` int(11) DEFAULT NULL,
  `schedule_days` text DEFAULT NULL,
  `session_hours` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `course_code` (`course_code`),
  KEY `idx_courses_verification` (`require_verification`,`verification_type`),
  KEY `idx_courses_status` (`course_status`),
  KEY `idx_courses_branch` (`branch_id`),
  KEY `idx_courses_module_title` (`module_title`),
  KEY `idx_courses_competency_name` (`competency_name`),
  KEY `idx_courses_nominal_hours` (`nominal_hours`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (1,'Name Course','Name Course','Name Course','NC2',80,80,'Nice Course ','','692284547322d_1_bs_W87qsqUHCigj_6wuQLg.png','archived','archived',0,'',0,'email','2025-11-07 14:03:42',NULL,NULL,NULL,NULL),(2,'Cat Course','Basic Competency 1','Cat Course','CC1',150,150,'Desc','Outcome','','archived','archived',0,'',0,'email','2025-11-25 16:25:18',NULL,3,'Mon,Wed,Fri',2),(3,'Test Course 1','Test Basic 1','Test Course 1','TC1',150,150,'Test course 1 afsafakuydhsglakjhdbgladjbfv,akjbrfgkjarilbgalbvgaliufhgaulbe','Test asdfjhbasldjbglakjhbglabjfgauwhefg;aoiuhefgakjsdbflakjwefluajsdljbtalkjebtadsjbtlakjsbet','6929b8ff0a71f_Screenshot_2025-05-17-12-38-42-760_com.facebook.katana.jpg','archived','archived',0,'',0,'email','2025-11-28 15:00:15',NULL,4,'Mon,Wed,Thu,Fri',2),(4,'Test Course','Test Competency','Advanced Module','TST-692d9aa90807d',10,12,'Desc','<ul><li>A</li><li>B</li></ul>',NULL,'archived','archived',0,'',0,'email','2025-12-01 13:39:53',NULL,NULL,NULL,NULL),(5,'Tmp','TmpComp','TmpMod','UNIT-692d9dcc4a714',10,10,NULL,'<p>LO</p>',NULL,'archived','archived',0,NULL,0,'email','2025-12-01 13:53:16',NULL,NULL,NULL,NULL),(6,'Automotive Servicing NC-1','Automotive Servicing NC-1','Automotive Servicing NC-1','ASNCI',488,241,'This course is designed to enhance the knowledge, skills and attitudes of an individual in the field of automotive servicing in accordance with industry standards. It covers core competencies such as; performance of basic engine servicing through removal and re-installation of components for gas and diesel engines.\r\nThis course is also designed to enhance the basic and common knowledge, skills and attitudes of an individual in the field of automotive servicing.\r\n','','692da55d1ea76_Euro Truck Simulator 2 Screenshot 2025.06.07 - 23.00.25.04.png','active','published',0,'',0,'email','2025-12-01 14:25:33',NULL,3,'Mon,Wed,Fri',4);
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enrollments`
--

DROP TABLE IF EXISTS `enrollments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enrollments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trainee_id` varchar(20) NOT NULL,
  `course_code` varchar(50) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `batch_name` varchar(100) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `remarks` text DEFAULT NULL,
  `student_id_verification` varchar(50) DEFAULT NULL,
  `email_verification` varchar(255) DEFAULT NULL,
  `verification_status` enum('pending','verified','rejected') DEFAULT 'pending',
  `date_requested` datetime DEFAULT current_timestamp(),
  `processed_date` datetime DEFAULT NULL,
  `processed_by` varchar(20) DEFAULT NULL,
  `progress_percentage` decimal(5,2) DEFAULT 0.00,
  `completion_date` datetime DEFAULT NULL,
  `final_grade` decimal(5,2) DEFAULT NULL,
  `drop_date` datetime DEFAULT NULL,
  `drop_reason` text DEFAULT NULL,
  `dropped_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `trainee_id` (`trainee_id`),
  KEY `course_code` (`course_code`),
  KEY `processed_by` (`processed_by`),
  KEY `idx_enrollments_status` (`status`),
  KEY `idx_enrollments_progress` (`progress_percentage`),
  KEY `idx_enrollments_verification_status` (`verification_status`),
  CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`trainee_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `enrollments_ibfk_2` FOREIGN KEY (`course_code`) REFERENCES `courses` (`course_code`),
  CONSTRAINT `enrollments_ibfk_3` FOREIGN KEY (`processed_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enrollments`
--

LOCK TABLES `enrollments` WRITE;
/*!40000 ALTER TABLE `enrollments` DISABLE KEYS */;
INSERT INTO `enrollments` VALUES (35,'31123082','ASNCI','Automotive Servicing NC-1',NULL,'approved',NULL,NULL,NULL,'pending','2025-12-02 07:25:22',NULL,NULL,0.00,NULL,NULL,NULL,NULL,NULL),(36,'31107421','ASNCI','Automotive Servicing NC-1',NULL,'approved',NULL,NULL,NULL,'pending','2025-12-02 07:25:33',NULL,NULL,0.00,NULL,NULL,NULL,NULL,NULL),(38,'411071438','ASNCI','Automotive Servicing NC-1','ASB1','approved','Aprovvd',NULL,NULL,'pending','2025-12-02 16:04:22','2025-12-02 16:05:01','1000000001',0.00,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `enrollments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grades`
--

DROP TABLE IF EXISTS `grades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trainee_id` varchar(50) NOT NULL,
  `course_code` varchar(50) NOT NULL,
  `activity_id` int(11) DEFAULT NULL,
  `quiz_id` int(11) DEFAULT NULL,
  `grade_type` enum('activity','quiz','assignment','final') NOT NULL,
  `score` decimal(5,2) NOT NULL,
  `max_score` int(11) NOT NULL,
  `percentage` decimal(5,2) DEFAULT NULL,
  `letter_grade` varchar(2) DEFAULT NULL,
  `graded_by` varchar(50) DEFAULT NULL,
  `graded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `trainee_id` (`trainee_id`),
  KEY `course_code` (`course_code`),
  KEY `idx_grades_trainee_course` (`trainee_id`,`course_code`),
  KEY `idx_grade_type` (`grade_type`),
  KEY `idx_graded_date` (`graded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grades`
--

LOCK TABLES `grades` WRITE;
/*!40000 ALTER TABLE `grades` DISABLE KEYS */;
/*!40000 ALTER TABLE `grades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hour_credits`
--

DROP TABLE IF EXISTS `hour_credits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hour_credits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trainee_id` varchar(20) NOT NULL,
  `course_code` varchar(50) NOT NULL,
  `credit_date` date NOT NULL,
  `hours` int(11) NOT NULL,
  `source` enum('schedule','manual') NOT NULL DEFAULT 'schedule',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_credit` (`trainee_id`,`course_code`,`credit_date`),
  KEY `idx_credits_user_course_date` (`trainee_id`,`course_code`,`credit_date`),
  KEY `fk_hour_credits_course` (`course_code`),
  CONSTRAINT `fk_hour_credits_course` FOREIGN KEY (`course_code`) REFERENCES `courses` (`course_code`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_hour_credits_user` FOREIGN KEY (`trainee_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hour_credits`
--

LOCK TABLES `hour_credits` WRITE;
/*!40000 ALTER TABLE `hour_credits` DISABLE KEYS */;
/*!40000 ALTER TABLE `hour_credits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_otps`
--

DROP TABLE IF EXISTS `password_reset_otps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_otps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `otp_code` varchar(6) NOT NULL,
  `expires_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_used` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `expires_at` (`expires_at`),
  KEY `is_used` (`is_used`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_otps`
--

LOCK TABLES `password_reset_otps` WRITE;
/*!40000 ALTER TABLE `password_reset_otps` DISABLE KEYS */;
INSERT INTO `password_reset_otps` VALUES (1,'411071438','470394','2025-12-02 15:33:04',0,'2025-12-02 14:23:04'),(2,'411071438','489648','2025-12-02 15:37:09',0,'2025-12-02 14:27:09'),(3,'411071438','425251','2025-12-02 15:47:18',0,'2025-12-02 14:37:18'),(4,'411071438','380967','2025-12-02 14:39:24',1,'2025-12-02 14:37:50');
/*!40000 ALTER TABLE `password_reset_otps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_analytics`
--

DROP TABLE IF EXISTS `quiz_analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_analytics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `correct_attempts` int(11) DEFAULT 0,
  `total_attempts` int(11) DEFAULT 0,
  `average_time` int(11) DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_quiz_question` (`quiz_id`,`question_id`),
  KEY `quiz_id` (`quiz_id`),
  KEY `question_id` (`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_analytics`
--

LOCK TABLES `quiz_analytics` WRITE;
/*!40000 ALTER TABLE `quiz_analytics` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz_analytics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_attempts`
--

DROP TABLE IF EXISTS `quiz_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_id` int(11) NOT NULL,
  `trainee_id` varchar(50) NOT NULL,
  `answers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`answers`)),
  `score` decimal(5,2) DEFAULT NULL,
  `max_score` int(11) DEFAULT NULL,
  `attempt_number` int(11) DEFAULT 1,
  `completed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `time_spent` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quiz_id` (`quiz_id`),
  KEY `trainee_id` (`trainee_id`),
  KEY `idx_attempts_trainee_quiz` (`trainee_id`,`quiz_id`),
  CONSTRAINT `fk_quiz_attempts_quiz` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_attempts`
--

LOCK TABLES `quiz_attempts` WRITE;
/*!40000 ALTER TABLE `quiz_attempts` DISABLE KEYS */;
INSERT INTO `quiz_attempts` VALUES (1,1,'411071438','{\"1\":{\"answer\":\"OP1\",\"correct\":true,\"points\":1}}',100.00,1,1,'2025-11-23 06:35:11',0),(3,1,'31107421','{\"1\":{\"answer\":\"OP1\",\"correct\":true,\"points\":1}}',100.00,1,2,'2025-11-23 06:49:33',0),(4,1,'31123082','{\"1\":{\"answer\":\"OP1\",\"correct\":true,\"points\":1}}',100.00,1,1,'2025-11-23 12:12:32',0),(5,2,'31123082','{\"2\":{\"answer\":\"true\",\"correct\":true,\"points\":1},\"3\":{\"answer\":\"false\",\"correct\":false,\"points\":0}}',50.00,2,1,'2025-11-23 12:42:13',0),(6,2,'31123082','{\"2\":{\"answer\":\"true\",\"correct\":true,\"points\":1},\"3\":{\"answer\":\"true\",\"correct\":true,\"points\":1}}',100.00,2,2,'2025-11-23 12:42:34',0);
/*!40000 ALTER TABLE `quiz_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_categories`
--

DROP TABLE IF EXISTS `quiz_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_code` varchar(50) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `course_code` (`course_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_categories`
--

LOCK TABLES `quiz_categories` WRITE;
/*!40000 ALTER TABLE `quiz_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_feedback`
--

DROP TABLE IF EXISTS `quiz_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attempt_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `feedback_text` text DEFAULT NULL,
  `feedback_type` enum('correct','incorrect','partial') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `attempt_id` (`attempt_id`),
  KEY `question_id` (`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_feedback`
--

LOCK TABLES `quiz_feedback` WRITE;
/*!40000 ALTER TABLE `quiz_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_questions`
--

DROP TABLE IF EXISTS `quiz_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_id` int(11) DEFAULT NULL,
  `course_code` varchar(50) NOT NULL,
  `question_text` text NOT NULL,
  `question_type` enum('multiple_choice','true_false','short_answer','essay') NOT NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`options`)),
  `correct_answer` text DEFAULT NULL,
  `points` int(11) DEFAULT 1,
  `difficulty` enum('easy','medium','hard') DEFAULT 'medium',
  `explanation` text DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `question_order` int(11) DEFAULT 0,
  `created_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `quiz_id` (`quiz_id`),
  KEY `course_code` (`course_code`),
  KEY `question_type` (`question_type`),
  KEY `difficulty` (`difficulty`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `fk_quiz_questions_quiz` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_questions`
--

LOCK TABLES `quiz_questions` WRITE;
/*!40000 ALTER TABLE `quiz_questions` DISABLE KEYS */;
INSERT INTO `quiz_questions` VALUES (1,1,'NC2','Q1','multiple_choice','[\"OP1\",\"OP2\"]','OP1',1,'easy','OP1 is correct',NULL,0,'21107477','2025-11-23 04:57:48'),(2,2,'NC2','Q1','true_false',NULL,'true',1,'medium','Coz it is true',NULL,0,'21107477','2025-11-23 12:40:32'),(3,2,'NC2','Q2','true_false',NULL,'true',1,'medium','Coz it is true',NULL,0,'21107477','2025-11-23 12:41:01');
/*!40000 ALTER TABLE `quiz_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_settings`
--

DROP TABLE IF EXISTS `quiz_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_id` int(11) NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quiz_id` (`quiz_id`),
  KEY `setting_key` (`setting_key`),
  CONSTRAINT `fk_quiz_settings_quiz` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_settings`
--

LOCK TABLES `quiz_settings` WRITE;
/*!40000 ALTER TABLE `quiz_settings` DISABLE KEYS */;
INSERT INTO `quiz_settings` VALUES (5,7,'due_date','2025-11-29 00:00:00'),(8,10,'due_date','2025-11-30 15:00:00'),(10,12,'due_date','2025-11-30 00:21:00'),(11,12,'due_date','2025-11-30 00:21:00'),(12,13,'due_date','2025-11-29 12:26:00'),(13,13,'due_date','2025-11-29 12:26:00'),(14,14,'due_date','2025-12-06 15:22:00'),(15,14,'due_date','2025-12-06 15:22:00');
/*!40000 ALTER TABLE `quiz_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quizzes`
--

DROP TABLE IF EXISTS `quizzes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quizzes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_code` varchar(50) NOT NULL,
  `competency_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `time_limit` int(11) DEFAULT NULL,
  `max_attempts` int(11) DEFAULT 1,
  `passing_score` decimal(5,2) DEFAULT 70.00,
  `is_randomized` tinyint(1) DEFAULT 0,
  `show_correct_answers` tinyint(1) DEFAULT 1,
  `status` enum('draft','published','archived') DEFAULT 'draft',
  `created_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `course_code` (`course_code`),
  KEY `category_id` (`competency_id`),
  KEY `created_by` (`created_by`),
  KEY `idx_quiz_status` (`status`),
  CONSTRAINT `quizzes_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `courses` (`course_code`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `quizzes_ibfk_2` FOREIGN KEY (`competency_id`) REFERENCES `competencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quizzes`
--

LOCK TABLES `quizzes` WRITE;
/*!40000 ALTER TABLE `quizzes` DISABLE KEYS */;
INSERT INTO `quizzes` VALUES (1,'NC2',1,'Quiz 1','test quiz',NULL,1,70.00,0,1,'published','21107477','2025-11-23 04:40:51','2025-11-28 15:42:44'),(2,'NC2',2,'Quiz 1','test quiz',NULL,3,70.00,1,1,'archived','21107477','2025-11-23 12:31:13','2025-11-28 15:42:47'),(7,'NC2',1,'Activity 1','First activity for the batch 3',NULL,3,70.00,1,1,'draft','21107477','2025-11-26 12:43:53','2025-11-28 15:42:49'),(10,'TC1',2,'Quiz 1','Quiz',NULL,2,70.00,1,1,'draft','21107477','2025-11-28 15:58:53','2025-11-28 15:58:53'),(12,'TC1',2,'Quiz 2','Quiz 2',NULL,3,70.00,0,1,'draft','21107477','2025-11-28 16:22:00','2025-11-28 16:22:00'),(13,'TC1',2,'Quiz 3','Quiz 3',NULL,1,70.00,0,1,'draft','21107477','2025-11-28 16:26:37','2025-11-28 16:29:43'),(14,'ASNCI',8,'Quiz 1','Act',NULL,1,70.00,0,1,'draft','21107477','2025-12-02 07:21:48','2025-12-02 07:21:48');
/*!40000 ALTER TABLE `quizzes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submissions`
--

DROP TABLE IF EXISTS `submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `submissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trainee_id` varchar(20) NOT NULL,
  `material_id` int(11) NOT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `score` decimal(5,2) DEFAULT NULL,
  `teacher_remarks` text DEFAULT NULL,
  `submitted_at` datetime DEFAULT current_timestamp(),
  `graded_at` datetime DEFAULT NULL,
  `graded_by` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `trainee_id` (`trainee_id`),
  KEY `material_id` (`material_id`),
  KEY `graded_by` (`graded_by`),
  CONSTRAINT `submissions_ibfk_1` FOREIGN KEY (`trainee_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `submissions_ibfk_2` FOREIGN KEY (`material_id`) REFERENCES `course_materials` (`id`),
  CONSTRAINT `submissions_ibfk_3` FOREIGN KEY (`graded_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submissions`
--

LOCK TABLES `submissions` WRITE;
/*!40000 ALTER TABLE `submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_backups`
--

DROP TABLE IF EXISTS `system_backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_type` enum('full','database','files') NOT NULL,
  `backup_path` varchar(500) NOT NULL,
  `backup_size` bigint(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(50) DEFAULT NULL,
  `status` enum('success','failed','in_progress') DEFAULT 'in_progress',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_backups`
--

LOCK TABLES `system_backups` WRITE;
/*!40000 ALTER TABLE `system_backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topic_activities`
--

DROP TABLE IF EXISTS `topic_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_id` int(11) DEFAULT NULL,
  `activity_title` varchar(255) DEFAULT NULL,
  `activity_description` text DEFAULT NULL,
  `activity_type` enum('assignment','quiz','project','discussion') DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `max_score` int(11) DEFAULT NULL,
  `max_attempts` int(11) DEFAULT 1,
  `created_by` varchar(50) DEFAULT NULL,
  `attachment_path` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `version` int(11) DEFAULT 1,
  `parent_activity_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `topic_activities_ibfk_1` (`topic_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `topic_activities_ibfk_1` FOREIGN KEY (`topic_id`) REFERENCES `course_topics` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `topic_activities_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topic_activities`
--

LOCK TABLES `topic_activities` WRITE;
/*!40000 ALTER TABLE `topic_activities` DISABLE KEYS */;
INSERT INTO `topic_activities` VALUES (1,1,'Research','clear instruction','quiz','2025-11-13 16:15:00','2025-11-06 17:15:00',100,1,'21107477',NULL,'2025-11-07 16:16:32',1,NULL),(2,2,'Research 1','Adasfdsafasdf','assignment',NULL,'2025-12-05 00:00:00',100,1,'21107477',NULL,'2025-11-30 16:43:51',1,NULL);
/*!40000 ALTER TABLE `topic_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topic_materials`
--

DROP TABLE IF EXISTS `topic_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_id` int(11) DEFAULT NULL,
  `material_title` varchar(255) DEFAULT NULL,
  `material_description` text DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `uploaded_by` varchar(50) DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `topic_materials_ibfk_1` (`topic_id`),
  KEY `uploaded_by` (`uploaded_by`),
  CONSTRAINT `topic_materials_ibfk_1` FOREIGN KEY (`topic_id`) REFERENCES `course_topics` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `topic_materials_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topic_materials`
--

LOCK TABLES `topic_materials` WRITE;
/*!40000 ALTER TABLE `topic_materials` DISABLE KEYS */;
INSERT INTO `topic_materials` VALUES (2,2,'Mats','Mats','692c7dbe35e13_UNIDOCCS LINK.txt','21107477','2025-11-30 17:24:14'),(3,3,'fghjgfngbdfghb','hdfghfghfg','692f134775000_Euro Truck Simulator 2 Screenshot 2025.06.07 - 23.00.25.04.png','21107477','2025-12-02 16:26:47');
/*!40000 ALTER TABLE `topic_materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_verification`
--

DROP TABLE IF EXISTS `user_verification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_verification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `verification_type` enum('email','student_id','phone') NOT NULL,
  `verification_code` varchar(100) DEFAULT NULL,
  `verification_data` varchar(255) DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT 0,
  `verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_verification`
--

LOCK TABLES `user_verification` WRITE;
/*!40000 ALTER TABLE `user_verification` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_verification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_verification_history`
--

DROP TABLE IF EXISTS `user_verification_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_verification_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `verification_type` enum('email','student_id','phone') NOT NULL,
  `verification_method` varchar(100) DEFAULT NULL,
  `verified_by` varchar(50) DEFAULT NULL,
  `verified_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('verified','rejected','expired') NOT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `verification_type` (`verification_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_verification_history`
--

LOCK TABLES `user_verification_history` WRITE;
/*!40000 ALTER TABLE `user_verification_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_verification_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification_tokens`
--

DROP TABLE IF EXISTS `verification_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `verification_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `token_type` enum('email','phone','student_id') NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_used` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `token` (`token`),
  KEY `expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification_tokens`
--

LOCK TABLES `verification_tokens` WRITE;
/*!40000 ALTER TABLE `verification_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `verification_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'elms_bts'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-04  1:10:20
